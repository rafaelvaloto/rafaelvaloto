<div align="center">
<img width="900"  alt="DualSense Controller" src="https://github.com/user-attachments/assets/658838d2-b19f-477e-a57c-ce038557f449" />
</div>

<h1 align="center">Middleware Unreal-Dualsense-Pro Documentation</h1>
<p align="center">
Your complete guide to integrating DualSense™ and DualShock®4 immersive features into your Unreal Engine projects.</p>
<p align="center">
  <a target="_blank" href="https://discord.gg/6x5NQMqTK" style="text-decoration: none; font-size: 16px;">
    <img src="https://img.icons8.com/color/48/000000/discord-logo.png" alt="Discord" width="24" height="24" style="vertical-align: middle; margin-right: 8px;"/>
    <b>Join our Discord server!</b>
  </a>
</p>

<p align="center">
<a target="_blank" href="https://www.fab.com/listings/d0836635-91a8-42cb-a78f-d34456cc042c">
Go to the official page on the Unreal Engine Marketplace</a>
</p>

## 🚀 Getting Started

### 🎮 Example Project Download (Unreal Engine 5.8)

Get started quickly with our comprehensive example project designed specifically for Unreal Engine 5.8. This project provides fully implemented, production-ready examples for advanced PlayStation controller integration.

* 👆 Touchpad: Precise absolute coordinate tracking, zoom gestures events.
* 🔊 Audio: Sound routing specifically directed to the controller's built-in speaker.
* 📳 Haptics: Advanced, high-fidelity haptic feedback for the DualSense.
* 🧭 Gyroscope & Motion: Motion tracking integration for camera control, steering, or precision aiming.
* 🔫 Adaptive Triggers: Weapon recoil for DualSense.

[📥Download the UE 5.8 Example Project (.zip)](https://drive.google.com/file/d/1OUxrr16t-mME3Ag3yEj7mxB4a0Xhsi4_/view?usp=drive_link)

[📥Download the CommonUI Example Project (.zip)](https://drive.google.com/file/d/109lAUyw8JOIwYF0VNh0B7aQbg21zIhtF/view?usp=drive_link)

## 🕹️ Input Settings

To enable hardware recognition for PlayStation controllers, include the following hardware device definitions in your configuration:

```.ini
; Windows platform
[InputPlatformSettings_Windows InputPlatformSettings] 
+HardwareDevices=(InputClassName="GCDevice::DeviceManager",HardwareDeviceIdentifier="DualSense",PrimaryDeviceType=Gamepad,SupportedFeaturesMask=260)
+HardwareDevices=(InputClassName="GCDevice::DeviceManager",HardwareDeviceIdentifier="DualSenseEdge",PrimaryDeviceType=Gamepad,SupportedFeaturesMask=260)
+HardwareDevices=(InputClassName="GCDevice::DeviceManager",HardwareDeviceIdentifier="DualShock4",PrimaryDeviceType=Gamepad,SupportedFeaturesMask=260)

; Linux platform
[InputPlatformSettings_Linux InputPlatformSettings]
+HardwareDevices=(InputClassName="GCDevice::DeviceManager",HardwareDeviceIdentifier="DualSense",PrimaryDeviceType=Gamepad,SupportedFeaturesMask=260)
+HardwareDevices=(InputClassName="GCDevice::DeviceManager",HardwareDeviceIdentifier="DualSenseEdge",PrimaryDeviceType=Gamepad,SupportedFeaturesMask=260)
+HardwareDevices=(InputClassName="GCDevice::DeviceManager",HardwareDeviceIdentifier="DualShock4",PrimaryDeviceType=Gamepad,SupportedFeaturesMask=260)

```

## 🛠️ Workflow: Live Haptic Prototyping (Console to Blueprint)
This complete workflow is detailed in the following guides:

* **[[💥 Managing Custom Triggers with Data Tables]]:** Learn to store and use your effects in Blueprints.

* **[[🎮 DualSense Trigger Effects: Console Commands & HEX Reference]]:** Learn to find and test effects using the console.

## 🧩 Extending Middleware 

### 🎮 Inputs

* **[[💉 Injecting Custom Device Logic (Custom DeviceManager)]]** 

### 💻 Platforms

* **[[🐧 Linux Custom Hardware Integration]]**

* **[[🍎 macOS Custom Hardware Integration]]**

* **[[🕹️ Extending for Other Platforms (e.g., PlayStation)]]** 

### 🎵 Audio

* **[[🎵 Custom Audio Policy Integration]]** 


## 🚀 Production Build (Shipping)

To learn how to generate your production license and safely import the binaries to package your final game (Shipping Build) with the Unreal Build Tool (UBT), please read the complete guide:

🔗 **[Read the Full License Generation Guide](https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki/%F0%9F%94%90-License-Generation-%E2%80%94-Controller-Support-v1,-v2-and-v3)**

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs">Back to the Main Repository</a>
</p>


