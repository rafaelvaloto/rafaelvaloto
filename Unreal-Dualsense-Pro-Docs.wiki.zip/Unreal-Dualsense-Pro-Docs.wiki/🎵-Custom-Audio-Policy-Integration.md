The Middleware project employs a decoupled, policy-based architecture (Policy-Based Design) for both hardware communication and the routing of audio and haptics. By default, the project includes a pre-configured and fully implemented WASAPI backend for the Windows platform.

Creating a custom policy and an audio registry is only necessary if you wish to extend haptic feedback support to other platforms (such as CoreAudio on macOS or ALSA on Linux) without needing to modify the engine's original source code. Provided below is a generic template for integrating your own platform.

## 1. The Audio Hardware Policy

The lowest level of the audio integration is the **Audio Policy**. This class defines how audio data is pushed to the physical controller. Below is a generic template for a platform-specific policy (`FPlatformAudioPolicy`), adapted from the standard `FNullSoundArchPolicy`.

```cpp
#pragma once
#include "GCore/Types/Structs/Context/DeviceContext.h"
#include <vector>
#include <string>

class FPlatformAudioPolicy
{
public:
    using Policy = FPlatformAudioPolicy;

    using DevicePathType = std::string;
    using AudioDeviceType = FPlatformAudioPolicy;
    using AudioDeviceIdType = std::string;
    using ContextType = FDeviceContext;

    using AudioRingBufferType = std::vector<float>;
    using AudioFrameCountType = int;

    int NumChannels = 4; // DualSense typically uses 4 channels for haptics
    int SampleRate = 48000;
    bool bInitialized = false;

    DevicePathType DevicePath;
    AudioDeviceIdType DeviceId;
    AudioRingBufferType RingBuffer;

    void Close() { /* Implement backend closure (e.g., snd_pcm_close, hid_close) */ }
    [[nodiscard]] bool IsValid() const { return bInitialized; }

    bool InitializeWithDeviceId(const AudioDeviceIdType& InDeviceId, int InSampleRate = 48000, int InNumChannels = 4) 
    { 
        // Implement your OS-specific audio initialization here
        bInitialized = true;
        return true; 
    }

    bool WriteHapticData(const std::vector<float>& AudioData) 
    { 
        // Write the PCM floating-point data to your platform's audio backend
        return true; 
    }

    bool InitializeAudioContainer(const ContextType* Context) 
    { 
        if(Context) { DevicePath = Context->Path; }
        return true; 
    }
};
```

## 2. The Audio Registry

The **Audio Registry** implements the `IAudioDevice` interface and manages the lifecycle of your Audio Policies. It maps each connected controller (via its path) to an active haptic audio stream.

```cpp
#pragma once

#include "GCore/Templates/TAudioDeviceRegistry.h"
#include "Helpers/DualSenseLog.h"
#include <unordered_map>
#include <memory>

using AudioHapticsHardwarePolicy = FPlatformAudioPolicy;
using namespace GCAudio;

class FPlatformAudioRegistry : public IAudioDevice
{
public:
    virtual ~FPlatformAudioRegistry() override = default;

    virtual void UnregisterAudioDevice(std::string Path) override
    {
        if (const auto it = DevicePolicies.find(Path); it != DevicePolicies.end())
        {
            UE_LOG(LogDualSense, Log, TEXT("Unregister audio policy for Controller path %s"), *FString(it->first.c_str()));
            DevicePolicies.erase(it);
        }
    }

    virtual void InitializeAudioContainer(FDeviceContext* Context) override
    {
        if (!Context)
        {
            UE_LOG(LogDualSense, Error, TEXT("InitializeAudioContainer: Context is null"));
            return;
        }

        if (const auto it = DevicePolicies.find(Context->Path); it != DevicePolicies.end())
        {
            UE_LOG(LogDualSense, Error, TEXT("InitializeAudioContainer: Device policy already exists"));
            return;
        }

        auto Policy = std::make_shared<GamepadCore::TAudioDeviceRegistry<AudioHapticsHardwarePolicy>>();
        if (!Policy->InitializeAudioContainer(Context))
        {
            return;
        }

        DevicePolicies.emplace(Context->Path, Policy);
        UE_LOG(LogDualSense, Log, TEXT("InitializeAudioContainer: %llu Registered audio policy for path %s."), DevicePolicies.size(), *FString(Context->Path.c_str()));
    }

    virtual void ProcessAudioHaptic(FDeviceContext* Context, const std::vector<float>& AudioData) override
    {
        if (!Context || AudioData.empty()) return;

        // Only process USB connections for audio haptics
        if (Context->ConnectionType != EDSDeviceConnection::Usb) return;

        // Find the policy mapped to this device path
        const auto it = DevicePolicies.find(Context->Path);
        if (it == DevicePolicies.end() || !it->second) return;

        auto& Policy = it->second;
        if (!Policy->IsValid()) return;

        // Send data to the platform backend
        Policy->Policy.WriteHapticData(AudioData);
    }

private:
    std::unordered_map<std::string, std::shared_ptr<GamepadCore::TAudioDeviceRegistry<AudioHapticsHardwarePolicy>>> DevicePolicies;
};
```

## 3. Injecting the Audio Registry

Finally, inject both your Custom Hardware Platform **and** your Custom Audio Registry at the application startup. This overrides the default middleware behavior completely.

Update your Game Module (`YourProject.cpp`) to inject the generic audio backend alongside your generic hardware policy:

```cpp
#include "YourProject.h"
#include "Modules/ModuleManager.h"
#include "Implementations/Platforms/Others/GamepadHardwareBridge.h"
#include "Platforms/YourPlatformPolicy.h"
#include "Platforms/PlatformAudioRegistry.h"
#include <memory>

class FYourProject : public FDefaultGameModuleImpl {
public:
    virtual void StartupModule() override {
        // Create custom hardware and audio implementations
        auto CustomPlatform = std::make_unique<YourPlatformPolicy::FYourHardware>();
        auto CustomAudio = std::make_unique<FPlatformAudioRegistry>();

        // Inject BOTH hardware and audio into the middleware bridge
        FGamepadHardwareBridge::InjectHardwarePlatform(std::move(CustomPlatform), std::move(CustomAudio));
        
        UE_LOG(LogTemp, Log, TEXT("YourProject Module: Custom Hardware & Audio Policies Injected."));
    }
};

IMPLEMENT_PRIMARY_GAME_MODULE(FYourProject, YourProject, "YourProject");
```


***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>