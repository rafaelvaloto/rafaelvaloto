
### 🎥 YouTube: 

* [Dynamic Common UI Input Icons in Action | Unreal Engine 5 Gameplay](https://youtu.be/R5YlwiOw5qo?si=AXgfnq1us4TN9MTX)
* [Real-Time Controller Hot-Swapping & Dynamic Common UI](https://youtu.be/CZJjkDJyVzE?si=SRVkvlB0kfPCufym)


* [📥Download the Example Project (.zip)](https://drive.google.com/file/d/109lAUyw8JOIwYF0VNh0B7aQbg21zIhtF/view?usp=drive_link)

This guide explains how to configure Unreal Engine 5's Common UI alongside the Enhanced Input system to achieve real-time controller hot-swapping and dynamic input icon updates.

---

## 1. Creating Controller Data Classes

To map physical devices to the UI, you need to create `CommonInputBaseControllerData` classes for each input platform.

**Relevant Paths & Assets:**
* `/Game/Variant_SideScroller/Blueprints/CommonUI`
* `BP_KBMInputsData`
* `BP_PS4InputsData`
* `BP_PS5InputsData`
* `BP_XBoxInputsData`

**Steps:**
1. Right-click in the Content Browser and select **Blueprint Class**.
2. Search for `CommonInputBaseControllerData` and create your subclasses.


<img width="310" height="281" alt="Create_BP_Class" src="https://github.com/user-attachments/assets/df2b8b08-6cc7-4079-9750-e485317ae3e5" />
<img width="310" height="281" alt="Create_KeyBoar_Mouse_Class" src="https://github.com/user-attachments/assets/99fbebff-0769-460b-a44a-671318685b13" />
<img width="310" height="281" alt="Create_XBox_BP_Class" src="https://github.com/user-attachments/assets/6479da72-992a-4524-a967-b5e53d877a05" />
<img width="310" height="94" alt="Final_Common" src="https://github.com/user-attachments/assets/470dfaf5-ff46-400c-9e50-d7ca00589473" />

---

## 2. Configuring Controller Data & Brushes

Each created Blueprint must be configured to map specific input keys to visual UI icons (brushes).

**Relevant Path:**
* `/Game/Variant_SideScroller/Blueprints/CommonUI/Icons`

**Steps:**
1. Open each Controller Data Blueprint.
2. Set the `Hardware Device Identifier` exactly as defined in your hardware mappings (e.g., `DualSense`, `DualShock4`, `XInputController`, `KBM`).
3. In the **Input Brush Data Map**, link the respective Key to its visual icon.

<img width="1915" alt="Config_InputsDataPerDevvice" src="https://github.com/user-attachments/assets/186a80ca-14e1-4d1d-adea-b2b7b97012c8" />
<img width="356" height="93" alt="Icons" src="https://github.com/user-attachments/assets/8c48a826-f1f3-404e-9bd4-0be071032ab0" />

---

## 3. Creating the Action Data Table

The Action Data Table acts as the bridge between your logical actions and the Common UI system.

**Relevant Path & Asset:**
* `/Game/Variant_SideScroller/Blueprints/CommonUI`
* `DT_CommonGenericInputAction`

**Steps:**
1. Create a new Data Table using the `CommonInputActionDataBase` structure.
2. Add a new row for each UI action (e.g., `MoveBackward`).
3. Link the row to your corresponding **Enhanced Input Action** (`UInputAction`). *Note: Leave Default Keys empty, as Enhanced Input will handle the bindings.*

<img width="323" alt="Create_DTCommon" src="https://github.com/user-attachments/assets/8120157d-fb90-411d-9ded-a6ce15b22eee" />

---

## 4. Project Settings Initialization

You must register your new Data Classes in the Engine's Project Settings so Common UI knows which data to load for each platform.

**Steps:**
1. Navigate to **Edit -> Project Settings -> Common Input Settings**.
2. Under **Platform Input -> Windows**, add your `BP_KBMInputsData`, `BP_PS4InputsData`, `BP_PS5InputsData`, and `BP_XBoxInputsData` to the **Controller Data** array.
3. Ensure **Enable Enhanced Input Support** is checked.

<img width="1024" height="368" alt="CommonInputSettings" src="https://github.com/user-attachments/assets/f3ca17ea-4784-4630-bcbf-c1672fd02da1" />


---

## 5. UI Integration with Common Action Widget

Finally, set up the widgets that will display the dynamic prompts on screen.

**Relevant Path & Asset:**
* `/Game/Variant_SideScroller/Blueprints/CommonUI/UI`
* `WBP_CommonActions`

**Steps:**
1. In your User Widget, add a `CommonActionWidget`.
2. In the Details panel, set the **Input Action** by selecting your `DT_CommonGenericInputAction` table and picking the specific row (e.g., `MoveBackward`).
3. The widget will now automatically update its icon based on the active device.

<img width="428" height="253" alt="Widget_Action" src="https://github.com/user-attachments/assets/66a25e4d-68e9-4cb1-a0f3-f29fb89de1b5" />
<img width="428" height="253" alt="WidgetStructure" src="https://github.com/user-attachments/assets/db8901e5-72ea-493e-b530-1a871604e400" />


---

## ⭐ Credits & Icon Licenses

* **Flat Gamepad Icons**
  https://robthefivenine.itch.io/flat-gamepad-icons
  Licensed under the Creative Commons Attribution-ShareAlike 4.0 International license. 
  https://creativecommons.org/licenses/by-sa/4.0/

* **PS4 Buttons** 
  © 2020 by ArksDigital is licensed under CC BY 4.0 
  https://arks.itch.io/ps4-buttons
  https://creativecommons.org/licenses/by-sa/4.0/

* **PC Keyboard & Mouse Icon Pack**
  Rendrify 
  https://www.fab.com/listings/b07743bb-31ad-476b-a942-ae47c3a0f82c
  Creative Commons Attribution (CC BY 4.0)
  https://creativecommons.org/licenses/by/4.0/ 

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>
