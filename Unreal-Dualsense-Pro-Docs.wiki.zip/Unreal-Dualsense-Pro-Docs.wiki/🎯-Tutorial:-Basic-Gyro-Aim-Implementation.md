This guide covers how to enable and apply gyroscope data to control the camera using the controller sensors.

## 🎮 1. Enable the Gyroscope
Before receiving any sensor data, the gyroscope must be initialized.
* On the **BeginPlay** event, call the **EnableGyroscopeValues** node from your `SonyGamepadSensorsProxy`.
* Set the target `ControllerId` (default is 0) and ensure `bEnableGyroscope` is set to `true`.

## 🔄 2. Gyro Reset and Recalibration
It is standard practice to allow the player to reset the camera and pause the gyro input to reposition their hands physically.
* Create an input action for resetting (e.g., `IA_Gyro_Reset`).
* On the **Started** trigger, set a `ResetGyro` boolean to `true` and call the **ResetGyroOrientation** function. 
* On the **Completed** trigger, set the `ResetGyro` boolean back to `false`.

## 🎯 3. Applying Camera Movement
Use the continuous vector data from the gyroscope to drive the camera.
* On the **Triggered** pin of your `IA_Gyro` input action, store the action value into a local variable (e.g., `LastVectorGyro`).
* Add a **Branch** node to verify that the **Not_PreBool** of your `ResetGyro` variable is true (meaning the player is not currently holding the reset button).
* **Pitch (Up/Down):** Extract the **Y-axis** from the gyro vector, negate the float (using **NegateFloat**), and connect it to the **AddControllerPitchInput** node.
* **Yaw (Left/Right):** Extract the **Z-axis** from the gyro vector and connect it directly to the **AddControllerYawInput** node.


## 📊 4. Additional Sensors (Optional)
If your project requires raw physical data, whether for UI debug information or procedural animations:
* Map `IA_Accel` to capture and store the accelerometer vector.
* Map `IA_Inclination` to capture and store the device's tilt/inclination vector.

---

## 📥 Example Project Download

To speed up your implementation, you can review the functional setup by downloading the demo project.

* [📥 **Download Example Project - Gyro Aim (.zip)**](https://drive.google.com/file/d/1n6x9lGsKJEP5pZaZ4rTnqeE6Q4O0vdmt/view?usp=drive_link) 

### 📂 File and Folder Structure
When downloading the project, you will find the assets following this exact directory structure:
* **Character and Code:** `/Content/InfimaGames/FreeFPSTemplate/Core/BP_Character.BP_Character`
* **Input Actions:** `/Content/InfimaGames/FreeFPSTemplate/Data/Sensors`

---
## ⭐ Credits

This tutorial project uses parts of the material [https://www.fab.com/listings/6a0af880...](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbjRra1JWSFJTTG92MTVmclNoN2pfOXR4dWRDd3xBQ3Jtc0trQ2FBZWotNDNJLWhBcm9GNFQ5YmQ4ZnF2Q2M0XzNXdVp1YVVoZjdIdy14LXhhcVQyNWR6QlNuLVNCdUQ3cl9CSzh4blVQejlmWVhXUF9wZGlVS2VoTmxYajAzSmtkSnViWlRxWTYzS1hhMnp0dmZVYw&q=https%3A%2F%2Fwww.fab.com%2Flistings%2F6a0af880-2b74-480c-a82c-8e597918dffe&v=EPY0HWrbz84) created by Infima Games, which is licensed under the Creative Commons Attribution 4.0 International license. The original material has been modified to integrate gyroscope rotation reading.

Important/Additional Notes:
Includes the "Low-Poly AAC Honey Badger" model ([https://skfb.ly/6SMsu](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbE5OUjNrbXNPM21VTEhqNVJSR2hoT25wSFd1Z3xBQ3Jtc0tsUWdqNW4zdFI1ZE9hU3paSXhteGFMX1ZXQUVPaVJFenJxTXg4MlI3V0ZHelJmZVFkYjRYZ1M0Mks1UVhDRXBVRml1bVBhQzhfbjFOZTFRZWlKb0x4dHkyQS1uX09pdm5XRVg5c1BKcTFRaFVMN2ctcw&q=https%3A%2F%2Fskfb.ly%2F6SMsu&v=EPY0HWrbz84)) by TastyTony which is licensed under Creative Commons Attribution ([http://creativecommons.org/licenses/b...](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbU4yYjE5ZkRjNkNsUUsxNnJ5MTdwTjVnU0lsd3xBQ3Jtc0trbzRFRHJDZm1ubU5fbVVHeHJQUllTVzZON3NVdlhJc2xhcG9CMXJhTVo3TjExWEVnRGJiamw1cWNUMkRYSnRXYmo5VjQ0MGR2SnVsN3ZqdTZNZnB1VFU5c1hURk9pblBDX1hMdkVSeW00b2FyU3lVQQ&q=http%3A%2F%2Fcreativecommons.org%2Flicenses%2Fby%2F4.0%2F%29&v=EPY0HWrbz84).

Requires Blender version 4.0.2 or higher, can be downloaded here

---

<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/Wiki"><strong> Back to the home </strong></a>
</p>
