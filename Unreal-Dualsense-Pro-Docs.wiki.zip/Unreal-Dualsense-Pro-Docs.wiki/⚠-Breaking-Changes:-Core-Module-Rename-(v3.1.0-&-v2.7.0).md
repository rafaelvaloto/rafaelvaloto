### ⚠ Breaking Changes: Core Module Rename (v3.1.0, v2.7.0, v1.10.1)

Due to a structural rename of the core plugin module in these updates, existing API function nodes in your Blueprints will lose their internal C++ references. 

**The function names and their behaviors have NOT changed**, but Unreal Engine will mark the existing nodes in your older projects as "Unresolved" or throw a compilation error.

### How to fix:
1. Open any Blueprint that uses the plugin's API and shows a compilation error.
2. Delete the broken/unresolved nodes.
3. Right-click the Blueprint graph, search for the exact same function name, and place the new node.
4. Reconnect your execution and data pins.
5. Compile and save the Blueprint.

---

```
"Plugins": [
   {
      "Name": "GamepadMiddleware",
      "Enabled": true
   }
]
```

### Visual Examples

#### Example 1: Gyroscope Node

**Before (Broken node):**

<img width="300" alt="Break_fn_Gyro" src="https://github.com/user-attachments/assets/8849b0ef-c2f8-43df-9bbe-aa303aab2ae4" />

**After (Fixed node):**

<img width="300" alt="Fix_Gyro" src="https://github.com/user-attachments/assets/24eef150-7b7b-4c04-9e12-90c6cc0e8a46" />

#### Example 2: Lightbar Node
**Before (Broken node):**

<img width="300" alt="Break_fn_Lightbar" src="https://github.com/user-attachments/assets/0bbb32c9-7194-4d26-93b8-653c6f7d8833" />

**After (Fixed node):**

<img width="300" alt="Fix_Lightbar" src="https://github.com/user-attachments/assets/8de937cf-9673-4dbc-b5ec-0dd164626df3" />

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>