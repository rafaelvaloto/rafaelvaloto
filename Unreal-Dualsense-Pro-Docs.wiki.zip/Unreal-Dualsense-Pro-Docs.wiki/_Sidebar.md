## Middleware Unreal-Dualsense pro

### 🚀 Getting Started
* [[Home|Home]]
* [Download on FAB](https://www.fab.com/listings/d0836635-91a8-42cb-a78f-d34456cc042c)

### 🎓 Tutorials
* [[DualSense Adaptive Triggers|🕹️ DualSense Adaptive Triggers Tutorial]]
* [[Common UI & Enhanced Input|⌨️🎮 Unreal Engine 5: Common UI & Enhanced Input Setup Guide]]

### 🛠️ Workflow: Haptic Prototyping
* [[Trigger Effects: Console & HEX|🎮 DualSense Trigger Effects: Console Commands & HEX Reference]]
* [[Managing Triggers with Data Tables|💥 Managing Custom Triggers with Data Tables]]

### 🧩 Extending Middleware

#### 🎮 Inputs
* [[Custom Device Logic|💉 Injecting Custom Device Logic (Custom DeviceManager)]]

#### 💻 Platforms
* [[Extending for MacOS Platforms|🍎 macOS Custom Hardware Integration]]
* [[Extending for Linux Platform|🐧 Linux Custom Hardware Integration ]]
* [[Extending for Other Platforms (e.g., PlayStation)|🕹️ Extending for Other Platforms (e.g., PlayStation)]]

#### 🎵 Audio
* [[Audio Policy Integration|🎵 Custom Audio Policy Integration]]

### 🚀 Production Build (Shipping)
* [[🔐 License Generation|🔐 License Generation — Controller Support v1, v2 and v3]]

### ⚠ Breaking Changes
* [[Breaking Changes (v1, v2, v3)|⚠ Breaking Changes: Core Module Rename (v3.1.0 & v2.7.0)]]
---
[⬅️ Back to Main Repository](https://github.com/valotogames/Unreal-Dualsense-Pro-Docs)