
You can also inject a custom implementation of the `DeviceManager`. This is useful if you want to implement your own input buffering, custom button mapping, or specialized haptic logic without modifying the middleware source.

> [!TIP]
> To ensure that your custom implementation works with native Unreal Engine assets (like **Haptic Feedback Effects**, **Force Feedback Assets**, and **Device Properties**), your class must correctly implement or override the methods from `IInputDevice` and `IHapticDevice`.

### Required Interfaces for Native Assets

If you want your custom manager to support native Unreal features, ensure it implements/overrides:

*   **`IHapticDevice`**: haptic assets.
    *   `SetHapticFeedbackValues`: Processes frequency and amplitude values from assets.
    *   `GetHapticFrequencyRange`: Determines the valid frequency range supported by the device.
    *   `GetHapticAmplitudeScale`: Returns the scaling factor for amplitude mapping.
*   **`IInputDevice`**: Required for standard vibration, light color, and properties.
    *   `SetChannelValues` / `SetChannelValue`: Essential for `UForceFeedbackEffect` assets.
    *   `SetLightColor` / `ResetLightColor`: Controls the controller's LED.
    *   `SetDeviceProperty`: Handles `UInputDeviceProperty` (e.g., Adaptive Triggers via Unreal 5.1+ system).
    *   `GetHapticDevice`: Returns the `IHapticDevice*` interface (usually `return this;`).
    *   `IsGamepadAttached`: Returns whether the device is currently connected.

### Custom implementation example:

```.ini
"Plugins": [
	{
		"Name": "GamepadMiddleware",
		"Enabled": true,
		"SupportedTargetPlatforms": [
			"Win64"
		]
	}
]
```

1. Create your custom class inheriting from `DeviceManager`:

```cpp
#include "DeviceManager.h"
#include "Modules/ModuleManager.h"
#include "GamepadMiddleware.h"

using namespace GCDevice;
class FMyCustomDeviceManager : public DeviceManager
{
public:
	using DeviceManager::DeviceManager;
	
    /** * Map to track the previous frame's touch state per DeviceID.
	 * Marked as 'mutable' so it can be updated within const methods.
	 */
	mutable TMap<int32, bool> DeviceTouchStates;
	
	// --- Touchpad implementation ---
	void DeviceManager::TouchpadImpl(FInputContext& FrameInput, const FPlatformUserId UserId,
	                                 const FInputDeviceId InputDeviceId, float DeltaTime) const
	{
		FDeviceRegistry* Registry = FDeviceRegistry::Get();
		if (!Registry)
		{
			return;
		}

		auto LibraryInstance = Registry->GetLibraryInstance(InputDeviceId);
		if (!LibraryInstance)
		{
			return;
		}

		auto TouchLibraryInstance = LibraryInstance->GetIGamepadTouch();
		if (!TouchLibraryInstance)
		{
			return;
		}
		
		// --- 1. Touch Handling ---
		if (TouchLibraryInstance->IsEnabledTouch() && !TouchLibraryInstance->IsEnabledGesture())
		{
            // --- 1. Your implementation touchpad. (Unreal Message Handler) ---
		    MessageHandler.Get().OnTouchStarted(nullptr, FVector2D(FrameInput.TouchPosition.X, FrameInput.TouchPosition.Y), 1.f, 0, UserId, InputDeviceId);
        }
		
		// --- 2. Gesture Mapping (Two-Finger Zoom) ---
		if (TouchLibraryInstance->IsEnabledGesture() && PluginSettings::GestureEvent == EGamepadGestureEvent::Zoom){}
    }

    // --- Device Property Events ---
	void DeviceManager::SetDeviceProperty(int32 ControllerId, const FInputDeviceProperty* Property)
	{
		if (!Property)
		{
			return;
		}
    }
    
    // --- Gyroscope, Accel, Tilt ---
    void DeviceManager::SensorsImpl(FInputContext& FrameInput, const FPlatformUserId UserId, const FInputDeviceId InputDeviceId, float DeltaTime) const
	{
		FDeviceRegistry* Registry = FDeviceRegistry::Get();
		if (!Registry)
		{
			return;
		}

		auto LibraryInstance = Registry->GetLibraryInstance(InputDeviceId);
		if (!LibraryInstance)
		{
			return;
		}

		auto SensorLibraryInstance = LibraryInstance->GetIGamepadSensors();
		if (!SensorLibraryInstance)
		{
			return;
		}

		if (!SensorLibraryInstance->IsEnabledMotionSensor())
		{
			return;
		}
    
        // Your Logic Proccessing the sensor data and sending it to Unreal's message handler
        // Example:
        // FQuat UnrealTilt = ...;
        // FQuat UnrealGyro = ...;
        // FVector UnrealAccel = ...;
        // MessageHandler.Get().OnMotionDetected(UnrealTilt, UnrealGyro, RawSensorQuat.GetUpVector(), UnrealAccel, UserId, InputDeviceId);
    }
};

```

2. Register your custom factory in your Game Module:
```cpp
class FMyProject : public FDefaultGameModuleImpl {
public:
    virtual bool IsGameModule() const override { return true; }

    virtual void StartupModule() override {
        FGamepadMiddlewareModule::SetCustomInputDeviceFactory([](const TSharedRef<FGenericApplicationMessageHandler>& InHandler)
        {
            UE_LOG(LogTemp, Log, TEXT("MyProject Game Module: Init FMyCustomDeviceManager."));
            return MakeShared<FMyCustomDeviceManager>(InHandler);
        });
    }
};

IMPLEMENT_PRIMARY_GAME_MODULE( FMyProject, MyProject, "MyProject" );
```


3. Build Configuration
   Ensure your project's Build.cs includes the middleware module and enables C++20 support:
```csharp
public class MyProject : ModuleRules
{
    public MyProject(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        
        // Required for Concepts and Policy-Based architecture
        CppStandard = CppStandardVersion.Cpp20;

        PublicDependencyModuleNames.AddRange(new string[] {
            ...
            "GamepadMiddleware"
        });
    }
}
```

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>
