## 🔐 License Generation — Controller Support v1, v2 and v3

Privacy Notice: Our DRM system is designed to protect both our intellectual property and your privacy. No personal data, hardware identifiers, or telemetry are collected or stored in your final compiled game (Shipping Build). Please read our full [Privacy Policy for DRM](https://gist.github.com/rafaelvaloto/cd037afbdcb69d179439d11d2edb4572) before generating your license.

This custom DRM implementation fully complies with the [Fab EULA requirements](https://www.fab.com/eula).

The Middleware unreal dualsense is strictly distributed under a seat-based licensing model to protect the intellectual property of the architecture. To package your final game (Production Build), you must generate a specific license through our dedicated panel.


### Step 1: Access the Licensing Panel
Go to the official licensing panel: [https://license-panel.rafael-valoto.workers.dev/](https://license-panel.rafael-valoto.workers.dev/)

<img width="1100" height="670" alt="License-Panel" src="https://github.com/user-attachments/assets/5e5ae8de-3f5a-4a9c-b68a-3401862891c8" />

### Step 2: Request the License
Enter your required project details into the panel. You will need your Fab Order ID. Once submitted, our GitHub Actions pipeline will dynamically inject a cryptographic watermark with your Unreal Engine Project Name directly into the C++ binaries during compilation.

If it's the first time you're generating the build, a message will appear asking you to wait until the purchase order is confirmed. This process is manual, so it may take a little while.

If you'd like to receive the confirmation by email, enter your email address in the field.

<img width="421" height="185" alt="request-for-approval-of-order-ID" src="https://github.com/user-attachments/assets/f100c3b7-c3ca-4edb-bc45-d16787eb6577" />

After the purchase order is confirmed, you will need to re-enter your details to generate the license, just like in step three.

### Step 3: Download Production Binaries
Wait a few minutes while the system compiles your exclusive `GamepadCore` libraries. Once the build finishes, download the generated `.zip` files containing the production binaries for your target platforms. 

<img width="420" height="371" alt="download-production-files" src="https://github.com/user-attachments/assets/28982552-329f-4946-aca9-9462845c18f9" />

### Step 4: Import Files into Unreal Engine
Extract the downloaded binaries into your project's plugin directory. `Project Settings > Plugins > Gamepad Middleware`

<img width="1515" height="307" alt="Import-Download-Files" src="https://github.com/user-attachments/assets/a39bb0a1-b930-472f-95dc-0f09840d867a" />

After these steps, you can safely package your final game using the Unreal Build Tool (UBT). The compiled core will silently validate the project name internally, ensuring compatibility with professional CI/CD server farms while protecting the middleware's source code.


***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>