
The middleware features a decoupled architecture using Policy-Based Design, allowing developers to seamlessly integrate custom platform implementations.

The primary advantage of this architecture is that you do not need to modify the middleware's core source code. You can simply inject your Linux-specific implementation during the application startup.

**Important Note for Linux:** Unreal Engine natively utilizes the **SDL2** library for hardware abstraction up to Engine version 5.7. Starting from version 5.8, it has been updated to use **SDL3**. Your implementation should reflect the specific SDL version your engine target uses.

## 1. Implementation via Hardware Policy

Low-level hardware communication is abstracted through a Template-Policy system. To add Linux support, you create a C++ struct in your project that implements the required hardware methods (`Read`, `Write`, `Detect`, etc.) utilizing the SDL HIDAPI wrapper (`SDL_hidapi.h`).

Below is an example policy structure based on a Linux/SDL implementation:
```.ini
; add linux platform .uproject
"Plugins": [
	{
		"Name": "GamepadMiddleware",
		"Enabled": true,
		"SupportedTargetPlatforms": [
			"Linux"
		]
	}
]
```

```cpp
#pragma once
#include "CoreMinimal.h"
#include <vector>
#include <cstring>
// Include your middleware types (FDeviceContext, EDSDeviceType, etc.)
// Include your sensor calibration header (FGamepadSensors)

namespace LinuxPlatformPolicy 
{
    struct FLinuxHardware 
    {
        FLinuxHardware() = default;

        // Implementation of the required Hardware Policy methods for Linux (SDL)
        void Read(FDeviceContext* Context) { /* SDL_hid_read implementation */ }
        void Write(FDeviceContext* Context) { /* SDL_hid_write implementation */ }
        void Detect(std::vector<FDeviceContext>& Devices) { /* SDL_hid_enumerate implementation */ }
        
        bool CreateHandle(FDeviceContext* Context) { 
            // e.g., Context->Handle = SDL_hid_open_path(Context->Path.c_str());
            
            ConfigureFeatures(Context); // Call to configure features after handle creation
            return true; 
        }
        
        void InvalidateHandle(FDeviceContext* Context) { /* SDL_hid_close cleanup */ }
        void ProcessAudioHaptic(FDeviceContext* Context) { /* Linux audio haptics logic */ }
        
        // Additional Linux-specific configuration steps
        void ConfigureFeatures(FDeviceContext* Context) {
            // Using SDL's hidapi wrapper
            SDL_hid_device* DeviceHandle = static_cast<SDL_hid_device*>(Context->Handle);

            using namespace FGamepadSensors;
            FGamepadCalibration Calibration;

            if (Context->DeviceType == EDSDeviceType::DualShock4)
            {
                if (Context->ConnectionType == EDSDeviceConnection::Usb)
                {
                    unsigned char FeatureBuffer[37] = {0};
                    std::memset(FeatureBuffer, 0, sizeof(FeatureBuffer));

                    FeatureBuffer[0] = 0x02;
                    if (SDL_hid_get_feature_report(DeviceHandle, FeatureBuffer, 37) < 0)
                    {
                        return;
                    }

                    DualShockCalibrationSensors(FeatureBuffer, Calibration, Context);
                }
                else
                {
                    unsigned char FeatureBuffer[41] = {0};
                    std::memset(FeatureBuffer, 0, sizeof(FeatureBuffer));

                    FeatureBuffer[0] = 0x05;
                    if (SDL_hid_get_feature_report(DeviceHandle, FeatureBuffer, 41) < 0)
                    {
                        return;
                    }

                    DualShockCalibrationSensors(FeatureBuffer, Calibration, Context);
                }

                Context->Calibration = Calibration;
            }
            else
            {
                unsigned char FeatureBuffer[41] = {0};
                std::memset(FeatureBuffer, 0, sizeof(FeatureBuffer));

                FeatureBuffer[0] = 0x05;
                if (SDL_hid_get_feature_report(DeviceHandle, FeatureBuffer, 41) < 0)
                {
                    return;
                }

                DualSenseCalibrationSensors(FeatureBuffer, Calibration, Context);
                Context->Calibration = Calibration;
            }
        }
    };
}
```

## 2. Injection via Game Module

Instead of modifying a singleton inside the middleware, you "inject" your custom Linux hardware platform during your Game Module's startup. This ensures your project-specific logic takes precedence over the default implementation.

Example Implementation in your Game Module (`MyProject.cpp`):

```cpp
#include "MyProject.h"
#include "Modules/ModuleManager.h"
#include "Implementations/Platforms/Others/GamepadHardwareBridge.h"
#include "Platforms/LinuxPlatformPolicy.h"
#include <memory>

class FMyProject : public FDefaultGameModuleImpl {
public:
    virtual bool IsGameModule() const override { return true; }

    virtual void StartupModule() override {
        // Injecting the custom Linux hardware platform into the middleware Bridge
        auto CustomPlatform = std::make_unique<LinuxPlatformPolicy::FLinuxHardware>();
        FGamepadHardwareBridge::InjectHardwarePlatform(std::move(CustomPlatform));
        
        UE_LOG(LogTemp, Log, TEXT("MyProject Game Module: Custom Linux Hardware Policy Injected."));
    }
};

IMPLEMENT_PRIMARY_GAME_MODULE(FMyProject, MyProject, "MyProject");
```

## 3. Build Configuration

Ensure your project's `Build.cs` includes the middleware module, enables C++20 support, and securely links the appropriate SDL frameworks required by the engine version you are targeting.

```csharp
public class MyProject : ModuleRules
{
    public MyProject(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        
        // Required for Concepts and Policy-Based architecture
        CppStandard = CppStandardVersion.Cpp20;

        PublicDependencyModuleNames.AddRange(new string[] { 
            "Core", 
            "CoreUObject", 
            "Engine", 
            "InputCore",
            "GamepadMiddleware" // middleware module
        });

        // Isolate Linux specific dependencies
        if (Target.Platform == UnrealTargetPlatform.Linux)
        {
            // Note: Use "SDL2" for UE <= 5.7, or "SDL3" for UE >= 5.8
            // Add your custom SDK libraries and Linux frameworks here
            // PublicDependencyModuleNames.Add("SDL2");
        }
    }
}
```

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>