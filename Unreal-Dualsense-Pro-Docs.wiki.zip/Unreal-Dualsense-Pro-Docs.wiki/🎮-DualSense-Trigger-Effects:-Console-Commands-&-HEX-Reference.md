

This page provides the technical reference for testing adaptive trigger effects using raw console commands in the Unreal Engine console. This is primarily intended for debugging, rapid prototyping, and fine-tuning haptic sensations.

## Appendix: Hexadecimal (HEX) Quick Reference

Using the console commands or Data Tables requires you to provide values in **hexadecimal (HEX)** format. This is just a different way of writing numbers. Most parameters you'll use (like force, position, or frequency) are ultimately converted to a single number between **0 and 255** (which is called a 'byte').

### 1. The Basic Digits (Decimal to HEX)

Hexadecimal uses 16 "digits" instead of 10.

| 0-9 | Hex. | 10-15 | Hex. | ...255 | Hex. |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0** | **`0x0`** | **10** | **`0x0A`** | **16** | **`0x10`** |
| **1** | **`0x1`** | **11** | **`0x0B`** | **64** | **`0x40`** |
| **9** | **`0x9`** | **15** | **`0x0F`** | **255** | **`0xFF`** |

<a target="_blank" href="https://www.rapidtables.com/convert/number/decimal-to-hex.html?x=">Open this link in a new tab to convert decimals from 0 to 255 to hexadecimal.</a>


## 2. Console Commands

These commands can be executed directly in the Unreal Engine output log console. The `<DeviceId>` parameter typically corresponds to the Player ID (e.g., 0, 1, etc.).

| Command | Parameters | Description |
| :--- | :--- | :--- |
| `ds.SetTrigR` | `<DeviceId> <hex bytes...>` | Sends a HEX byte array (up to 10 bytes) directly to the **right** trigger. |
| `ds.SetTrigL` | `<DeviceId> <hex bytes...>` | Sends a HEX byte array (up to 10 bytes) directly to the **left** trigger. |
| `ds.ClearTrig` | `<DeviceId>` | Removes all trigger effects (sends mode 0x00 to both). |
| `ds.DumpTrig` | `<DeviceId>` | Prints the current HEX *override* bytes for both triggers to the console. |

---

## 3. HEX Mapping Reference: DualSense Triggers

The DualSense controller accepts a 10-byte array to configure each trigger. The first byte (`Mode`) defines the effect type.

### 🟢 0x00 - Off (Reset)
* **Base Command:** `[00 00 00 00 00 00 00 00 00 00]`
* **Description:** Disables any resistance or vibration on the trigger.
* **Console Example:** `ds.SetTrigR 1 00`

### 🔵 0x01 - Continuous Resistance
* **Description:** Applies a continuous resistance force starting from an initial position.
* **Structure:** `[01] [StartPos 0-255] [Force 0-255] [00 00 00 00 00 00 00]`
* **Notes:** `StartPos` (Start Position) and `Force` are 0-255 values.
* **Console Example:**
(Starts resistance at ~75% with max force)
```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 01 4f cf
ds.SetTrigR 1 01 8c ff
ds.SetTrigR 1 01 a5 ff
ds.SetTrigR 1 01 8a ff
ds.SetTrigR 1 01 4a ff
ds.SetTrigR 1 01 1a ff
```

### 🟡 0x02 - GameCube Click (Simple Feedback)
* **Description:** Simulates a digital "click" at the end of the trigger pull, similar to a GameCube controller button.
* **Base Command (Fixed):** `[02 80 a0 ff 00 00 00 00 00 00]`
* **Console Examples (from Log):**

```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 02 80 a0 ff
ds.SetTrigL 1 02 80 a0 ff
```

### 🔵 0x21 - Inclination Feedback
* **Description:** Linear resistance between two points with configurable start and end forces. Ideal for pedals (gas/brake) or springs.
* **Console Examples (from Log):**

```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 21 fe 03 f8 ff ff 3f
ds.SetTrigL 1 21 c0 03 00 00 fc 3f
ds.SetTrigR 1 21 c7 00 ff 01 fc 00
ds.SetTrigR 1 21 f8 03 00 48 92 24
ds.SetTrigR 1 21 0e 03 00 00 92 24
ds.SetTrigR 1 21 c0 03 00 00 00 3f
ds.SetTrigR 1 21 fe 03 f8 6f bb 2d
ds.SetTrigR 1 21 fe 03 f8 ed b6 24
ds.SetTrigR 1 21 fe 03 b8 dd 72 13
ds.SetTrigR 1 21 fe 03 b8 cb 4d 01
ds.SetTrigR 1 21 e0 03 00 80 77 02
ds.SetTrigR 1 21 fe 03 b0 ed ff 3f
ds.SetTrigR 1 21 fe 03 d0 c6 d6 3e
ds.SetTrigR 1 21 f0 03 00 f0 4e
ds.SetTrigR 1 21 fe 03 b8 b9

```

### 🟡 0x22 - Bow (Tension)
* **Description:** Simulates the tension of pulling a bowstring, with a "snap-back".
* **Structure:** `[22] [Start_Zone] [Behavior_Flag] [Force_Amplitude]`
```cpp
Command Ex: 22 82 00 3F
Breakdown:
  22 = Bow
  82 = B1 -> high=8 (END=8), low=2 (START=2)
  00 = B2 -> Range (no click)
  3F = B3 -> spring profile 3 (high nibble) + force 0xF (max)
```

Result: Strong, clickless bow from position 2 to 8.

* **Console Examples (from Log):**

```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 22 02 01 0f
ds.SetTrigR 1 22 82 02 3f
ds.SetTrigR 1 22 02 01 3b
ds.SetTrigR 1 22 02 01 3f
ds.SetTrigR 1 22 82 00 3f
ds.SetTrigR 1 22 04 01 24
ds.SetTrigR 1 22 02 02 1e
ds.SetTrigR 1 22 02 01 3f
```

### 🟣 0x23 - Galloping
* **Description:** Rhythmic effect that simulates horse steps.
* **Structure:** `[23] [StartPos_Bitmask] [EndPos_Bitmask] [Foot1_Foot2_Nibbles] [Frequency 0-255] ...`
* **Notes:** Byte 3 combines the "foot" positions (4 bits each).
* **Console Examples (from Log):**

```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 23 02 02 1e 04
ds.SetTrigR 1 23 04 01 0f 04
ds.SetTrigR 1 23 20 02 0f 02
ds.SetTrigR 1 23 04 01 0f 04
ds.SetTrigR 1 23 20 02 0f 02
```


### 🔴 0x25 - Weapon (Semiautomatic)
* **Description:** Resistance simulating a firearm trigger, with a "break point" before firing.
* **Structure:** `[25] [StartPos_Bitmask_LSB] [StartPos_Bitmask_MSB] [Force 0-255] ...`
* **Console Examples (from Log):**
```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 25 20 01 07
ds.SetTrigR 1 25 c0 00 02
ds.SetTrigR 1 25 40 01 07
ds.SetTrigR 1 25 10 01 07
ds.SetTrigR 1 25 80 01 07
ds.SetTrigR 1 25 08 01 07
ds.SetTrigR 1 25 20 01 00
```

### 🟤 0x26 - Automatic Gun (Vibration)
* **Description:** Continuous vibration on the trigger. Ideal for simulating automatic weapons.
* **Structure:** `[26] [StartPos 0-255] [Amplitude 0-255] [Frequency 0-255] ...`
* **Notes:** The console examples below work perfectly with the Custom Trigger node. (The plugin also offers a dedicated Blueprint node, Set Automatic Gun Effect, which uses simpler parameters like 'Amplitude' and 'Frequency' instead of HEX.).
* **Console Examples (from Log):**

```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 26 f8 3 00 00 8f 3f 0 0 9
ds.SetTrigR 1 26 fc 3 80 24 49 12 0 0 9
ds.SetTrigR 1 26 f0 3 00 40 92 24 0 0 9
ds.SetTrigR 1 26 fc 3 80 24 49 12 0 0 9
ds.SetTrigR 1 26 f0 3 00 40 92 24 0 0 9
ds.SetTrigR 1 26 80 3 00 00 e0 3f 0 0 4
ds.SetTrigR 1 26 00 2 00 00 00 38 0 0 0c
ds.SetTrigR 1 26 00 2 00 00 00 38 0 0 04
ds.SetTrigR 1 26 00 3 00 00 00 1b 0 0 0c
```

### ⚫ 0x27 - Machine

* **Description:** Rhythmic vibration more complex than 0x26, allowing configuration of two amplitude levels and a period.

* **Structure:** `[27] [Start_Zone] [Behavior_Flag] [Force_Amplitude] [Period] [Frequency]`

* **Notes:**
  - **Start_Zone**: Dropdown (int) ```{ Start = 130 (0x82), Middle = 132 (0x84), End = 128 (0x80), MidLow = 136 (0x88) }```
  - **Behavior_Flag**: Dropdown (int) ```{ EndAtPos = 1, KeepEffect = 2 }```
  - **Force_Amplitude** (High Nibble) must be 1-3. Amplitude (Low Nibble) must be 10-15.
  - **Period**: Slider (int) 0 - 20
  - **Frequency**: Slider (int) 0 - 40 (ex: 2)


**Console Examples (from Log):**
```cpp
ds.SetTrigR <DeviceId> <hex bytes...>
ds.SetTrigR 1 27 02 02 3a 0a 05
ds.SetTrigR 1 27 02 02 3a 0a 05
ds.SetTrigR 1 27 40 01 3a 0a 05
ds.SetTrigR 1 27 10 01 28 0f 06
ds.SetTrigR 1 27 80 02 32 19 02
ds.SetTrigR 1 27 10 01 28 0f 0d
```

* **[[💥 Managing Custom Triggers with Data Tables]]** Learn to store and use your effects in Blueprints.

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>