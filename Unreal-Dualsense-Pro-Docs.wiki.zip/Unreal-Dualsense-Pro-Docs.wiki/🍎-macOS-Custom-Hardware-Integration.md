The middleware features a decoupled architecture using Policy-Based Design, allowing developers to seamlessly integrate custom platform implementations. 

The primary advantage of this architecture is that you do not need to modify the middleware's core source code. You can simply inject your macOS-specific implementation (utilizing backends like `hidapi` and `IOKit`) during the application startup.

## 1. Implementation via Hardware Policy

Low-level hardware communication is abstracted through a Template-Policy system. To add macOS support, you create a C++ struct in your project that implements the required hardware methods (`Read`, `Write`, `Detect`, etc.) specifically tailored for Mac.

Below is an example policy structure based on a macOS implementation:

```.ini
; add macos platform .uproject
"Plugins": [
	{
		"Name": "GamepadMiddleware",
		"Enabled": true,
		"SupportedTargetPlatforms": [
			"Mac"
		]
	}
]
```

```cpp
#pragma once
#include "CoreMinimal.h"
#include <vector>
// Include your middleware types (FDeviceContext, etc.)

namespace MacPlatformPolicy
{
    struct FMacHardware
    {
        FMacHardware() = default;
        
        void Detect(std::vector<FDeviceContext>& Devices) { /* macOS hid_enumerate implementation */ }
        void InvalidateHandle(FDeviceContext* Context) { /* hid_close cleanup */ }

        // Implementation of the required Hardware Policy methods for macOS
        void Read(FDeviceContext* Context) { /* macOS hid_read implementation */
            hid_device* DeviceHandle = static_cast<hid_device*>(Context->Handle);

            // Check if the DeviceType and ConnectionType are correct before attempting to read
            // only read the full report length for DS4 over Bluetooth, because it has a larger input report size
            if (Context->ConnectionType == EDSDeviceConnection::Bluetooth && Context->DeviceType == EDSDeviceType::DualShock4)
            {
                constexpr size_t InputReportLength = 547;
                int BytesRead = hid_read(Context->Handle, Context->BufferDS4, InputReportLength);
                if (BytesRead < 0)
                {
                    Context->IsConnected = false;
                }
            }
            else
            {
                const size_t InputBufferSize = Context->ConnectionType == EDSDeviceConnection::Bluetooth ? 78 : 64;
                int BytesRead = hid_read(Context->Handle, Context->Buffer, InputBufferSize);
                if (BytesRead < 0)
                {
                    Context->IsConnected = false;
                }
            }
        }
        
        void Write(FDeviceContext* Context) { /* macOS hid_write implementation */
            size_t InReportLength = Context->DeviceType == EDSDeviceType::DualShock4 ? 32 : 74;
	        size_t OutputReportLength = Context->ConnectionType == EDSDeviceConnection::Bluetooth ? 78 : InReportLength;
        }
        
        bool CreateHandle(FDeviceContext* Context) {
            // e.g., hid_open_path(Context->Path.c_str());
            
            ConfigureFeatures(Context); // Call to configure features after handle creation
            return true;
        }
        
        /* macOS audio haptics Bluetooth */
        void ProcessAudioHaptic(FDeviceContext* Context) {
            hid_device* DeviceHandle = static_cast<hid_device*>(Context->Handle);
            if (!Context || !DeviceHandle)
            {
                return;
            }
        
            if (Context->ConnectionType != EDSDeviceConnection::Bluetooth)
            {
                return;
            }
        
            constexpr size_t BufferSize = sizeof(Context->BufferHapitcs);
            int BytesWritten = hid_write(DeviceHandle, Context->BufferHapitcs, BufferSize);
            if (BytesWritten < 0)
            {
                // Log error handling
            }
        }
        
        // Additional Mac-specific configuration steps
        void ConfigureFeatures(FDeviceContext* Context) {
            hid_device* DeviceHandle = static_cast<hid_device*>(Context->Handle);

            using namespace FGamepadSensors;
            FGamepadCalibration Calibration;
        
            if (Context->DeviceType == EDSDeviceType::DualShock4)
            {
                if (Context->ConnectionType == EDSDeviceConnection::Usb)
                {
                    unsigned char FeatureBuffer[37] = {0};
                    std::memset(FeatureBuffer, 0, sizeof(FeatureBuffer));
        
                    FeatureBuffer[0] = 0x02;
                    if (!hid_get_feature_report(DeviceHandle, FeatureBuffer, 37))
                    {
                        return;
                    }
        
                    DualShockCalibrationSensors(FeatureBuffer, Calibration, Context);
                }
                else
                {
        
                    unsigned char FeatureBuffer[41] = {0};
                    std::memset(FeatureBuffer, 0, sizeof(FeatureBuffer));
        
                    FeatureBuffer[0] = 0x05;
                    if (!hid_get_feature_report(DeviceHandle, FeatureBuffer, 41))
                    {
                        return;
                    }
        
                    DualShockCalibrationSensors(FeatureBuffer, Calibration, Context);
                }
        
                Context->Calibration = Calibration;
            }
            else
            {
                unsigned char FeatureBuffer[41] = {0};
                std::memset(FeatureBuffer, 0, sizeof(FeatureBuffer));
        
                FeatureBuffer[0] = 0x05;
                if (!hid_get_feature_report(DeviceHandle, FeatureBuffer, 41))
                {
                    return;
                }
        
                DualSenseCalibrationSensors(FeatureBuffer, Calibration, Context);
                Context->Calibration = Calibration;
            }
        }
    };
}
```

## 2. Injection via Game Module

Instead of modifying a singleton inside the middleware, you "inject" your custom macOS hardware platform during your Game Module's startup. This ensures your project-specific logic takes precedence over the default HID implementation.

Example Implementation in your Game Module (`MyProject.cpp`):

```cpp
#include "MyProject.h"
#include "Modules/ModuleManager.h"
#include "Implementations/Platforms/Others/GamepadHardwareBridge.h"
#include "Platforms/MacPlatformPolicy.h"
#include <memory>

class FMyProject : public FDefaultGameModuleImpl {
public:
    virtual bool IsGameModule() const override { return true; }

    virtual void StartupModule() override {
        // Injecting the custom macOS hardware platform into the middleware Bridge
        auto CustomPlatform = std::make_unique<MacPlatformPolicy::FMacHardware>();
        FGamepadHardwareBridge::InjectHardwarePlatform(std::move(CustomPlatform));
        
        UE_LOG(LogTemp, Log, TEXT("MyProject Game Module: Custom macOS Hardware Policy Injected."));
    }
};

IMPLEMENT_PRIMARY_GAME_MODULE(FMyProject, MyProject, "MyProject");
```

## 3. Build Configuration

Ensure your project's `Build.cs` includes the middleware module, enables C++20 support, and securely links any macOS-specific frameworks (like `IOKit` or `CoreFoundation`) required by your hardware libraries (e.g., `hidapi`).

```csharp
public class MyProject : ModuleRules
{
    public MyProject(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        
        // Required for Concepts and Policy-Based architecture
        CppStandard = CppStandardVersion.Cpp20;

        PublicDependencyModuleNames.AddRange(new string[] { 
            "Core", 
            "CoreUObject", 
            "Engine", 
            "InputCore",
            "GamepadMiddleware" // middleware module
        });

        // Isolate macOS specific dependencies
        if (Target.Platform == UnrealTargetPlatform.Mac)
        {
            // Add your custom SDK libraries and macOS frameworks here
            // PublicSystemIncludePaths.Add("/opt/homebrew/include");
            // PublicAdditionalLibraries.Add("/opt/homebrew/lib/libhidapi.dylib");
            PublicFrameworks.AddRange(new string[] { "IOKit", "CoreFoundation" });
        }
    }
}
```

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>