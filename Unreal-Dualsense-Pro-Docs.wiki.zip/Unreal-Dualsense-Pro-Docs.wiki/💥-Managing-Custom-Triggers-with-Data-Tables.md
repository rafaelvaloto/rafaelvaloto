
So, you've been using the console commands from our **[[🎮-DualSense-Trigger-Effects:-Console-Commands-&-HEX-Reference]]** page and found some killer trigger effects. Awesome. But now what? You don't want to hard-code those HEX arrays in every single Blueprint, do you? That's a maintenance nightmare.

This tutorial shows you how to store all your custom HEX trigger effects in a central **Data Table**. This makes them reusable, easy to tweak, and simple to call from any Blueprint.

## Step 1: Create the Data Structure (Struct)

1.  In the Content Browser, right-click and go to **Blueprints > Structure**.

<img width="637" height="266" alt="S_Structure_Triggers" src="https://github.com/user-attachments/assets/0ea26ce2-469f-457c-992c-cd0fef8cfc3b" />

## Step 2: Create the Data Table or Struct

Now we'll create the Data Table or Struct that uses this structure to store our effects.

For each row, expand the `Raw_Trigger` array and add **10 elements** (one for each byte).

**Example (Automatic Gun):**
* **Raw_Trigger:**
    * `[0]` "0x26"
    * `[1]` "0xf8"
    * `[2]` "0x03"
    * `[3]` "0x0"
    * `[4]` "0x0"
    * `[5]` "0x0"
    * `[6]` "0xf3"
    * `[7]` "0x0"
    * `[8]` "0x0"
    * `[9]` "0x09"

<img width="900" alt="S_Triggers" src="https://github.com/user-attachments/assets/4ebab078-514a-4a66-868e-c090543d0325" />

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>
