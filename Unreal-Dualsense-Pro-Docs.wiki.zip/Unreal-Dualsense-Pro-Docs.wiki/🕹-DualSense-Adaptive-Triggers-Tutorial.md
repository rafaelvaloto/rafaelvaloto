This tutorial shows how to set up and control the DualSense adaptive triggers (R2/L2) using Blueprints, driven by an Enhanced Input action.

## Resources

Example Project: [Download the Unreal Engine Project Here](https://drive.google.com/file/d/1Ypu6ruRzrUQni4K5WQ8aMXIc-ocVIDFh/view?usp=sharing)


## 1. Get the Local Player ID (Event BeginPlay)

All trigger nodes require a **Controller Id**. You should retrieve this information once during `Event BeginPlay` and store it in a variable (`Local Player Id`).

1. From `Event BeginPlay`, add a **Get Controller** node (Target is Pawn, `self`).
2. Connect the `Return Value` to a **Cast To PlayerController** node (Object pin).
3. From the `As Player Controller` pin, call **Get Local Player Controller ID** (Player pin).
4. Use a **SET** node to store this result in a new variable called `Local Player Id`.
5. Call the **Stop Trigger (New)** node. Connect your `Local Player Id` to the *Controller Id* pin and set *Hand* to `Any Hand`. This ensures no leftover effects are active when the game starts.
6. (Optional) Call your own custom event (e.g., `On Change Trigger Event` or `Update Output`) to refresh your UI or debug output.


<img width="1193" height="332" alt="Begin_Play_Reset_Triggers" src="https://github.com/user-attachments/assets/98c8bcd7-1c1f-44c8-81ba-26dedbcaa03e" />

## 2. Hook the Effect to the Input Action

To activate the triggers when firing, you need to configure events driven by your Enhanced Input Action.

### Input Action Setup
In your blueprint, find your input node (e.g., `EnhancedInputAction IA_Shoot`) and connect the execution pins to your custom logic:

*   **Started:** Triggers the **Start Trigger Event** (applies the adaptive trigger effect). Optional: Add a `Print String` ("Start Trigger") for debugging.
*   **Triggered:** Triggers the **On Change Trigger Event** (fires every frame while the button is held).
*   **Completed:** Triggers the **Stop Trigger Event** (stops the effect). Optional: Add a `Print String` ("Stop Trigger") for debugging.

<img width="1097" alt="IA_Shoot" src="https://github.com/user-attachments/assets/60c86e08-31f7-4dea-bf6f-eed84ae92bf6" />
<img width="1097" alt="Map_Shoot" src="https://github.com/user-attachments/assets/00b44334-f2d2-458d-92fa-5a84818d9356" />
<img width="1097" height="491" alt="IA_Shoot_Event" src="https://github.com/user-attachments/assets/9ce208f7-6206-41d8-ac51-4d4b9f3537b4" />

### Custom Events
Create the logic for each of the custom events triggered by your input:

**1. On Change Trigger Event**
This updates parameters continuously or sends data to the UI while the action is happening.

<img width="1275" height="346" alt="OnCHange_Trigger_Event" src="https://github.com/user-attachments/assets/93272e3a-5f73-4c6a-8dac-2976e6ed0088" />

**2. Start Trigger Event**
This applies the adaptive trigger effect (like a *Custom Trigger* or *Automatic Gun*). Make sure to pass the `Local Player Id` variable.

<img width="1246" height="386" alt="OnStartTrigger_Event" src="https://github.com/user-attachments/assets/723b78ac-ae3c-497c-9a88-57f7db876d24" />

**3. Stop Trigger Event**
This calls the **Stop Trigger (New)** node using the `Local Player Id` and the desired `Hand`, cleanly returning the trigger to its normal state.

<img width="646" height="305" alt="Stop_Trigger_Event" src="https://github.com/user-attachments/assets/ec771819-7caf-4f45-8946-ee04e0e7d406" />

## 3. Alternative: Automatic Gun (0x26)

Instead of using the generic **Custom Trigger**, you can use the **Automatic Gun (0x26)** node. This node is more intuitive as it uses pre-configured zones and positions to simulate weapon feedback.

| Pin | Description | Example |
|---|---|---|
| **Controller Id** | The variable storing the player's ID | `Local Player Id` |
| **Start Zone** | Where the trigger resistance begins | `End (75-100%)` |
| **Behavior** | How the effect acts over the trigger pull | `Sustained (Extend to End)` |
| **Recoil** | The strength of the feedback | `Heavy Recoil` |
| **Frequency** | The vibration frequency | Connect a `Frequency` variable |
| **Hand** | Which trigger receives the effect | `Left` / `Right` / `Any Hand` |

<img width="954" height="575" alt="alt_node" src="https://github.com/user-attachments/assets/c0856a3f-203f-469e-95ab-11787a6cb9d9" />

# ⭐ Credits



### First Person Rifle Animation - xidePunk Studio | [Fab.com Marketplace](https://www.fab.com/listings/ceee0b8a-5ed1-4bc9-999d-d9a67f4ae384) | [Licence: Creative Commons 4.0](https://creativecommons.org/licenses/by/4.0/)

***
<p align="center">
  <a href="https://github.com/valotogames/Unreal-Dualsense-Pro-Docs/wiki">Back to the home</a>
</p>